import asyncio
from viam.module.module import Module
try:
    from models.gpu_transform import GPUTransformCamera
except ModuleNotFoundError:
    # when running as local module with run.sh
    from .models.gpu_transform import GPUTransformCamera


async def main():

    Registry.register_resource_creator(
        Camera.API,
        GPUTransformCamera.MODEL,
        ResourceCreatorRegistration(
            GPUTransformCamera.new, GPUTransformCamera.validate_config
        ),
    )
    module = Module.from_args()

    module.add_model_from_registry(Camera.API, GPUTransformCamera.MODEL)
    await module.start()


if __name__ == "__main__":
    asyncio.run(main())