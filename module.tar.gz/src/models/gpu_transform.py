import sys
from typing import (Any, ClassVar, Dict, Final, List, Mapping, Optional,
                    Sequence, Tuple)

from typing_extensions import Self
from viam.components.camera import *
from viam.media.video import NamedImage, ViamImage
from viam.proto.app.robot import ComponentConfig
from viam.proto.common import Geometry, ResourceName, ResponseMetadata
from viam.proto.component.camera import GetPropertiesResponse
from viam.resource.base import ResourceBase
from viam.resource.easy_resource import EasyResource
from viam.resource.types import Model, ModelFamily
from viam.utils import ValueTypes
from viam.resource.registry import Registry, ResourceCreatorRegistration
from viam.proto.component.camera import Properties
from viam.proto.common import ResourceName
from viam.logging import getLogger
from transform_pipeline import GPUTransformPipeline

LOGGER = getLogger(__name__)

class GPUTransformCamera(Camera):
       MODEL: ClassVar[Model] = Model(ModelFamily("isha-org", "gpu-transform-camera"), "gpu-transform")
    
    def __init__(self, name: str):
        super().__init__(name)
        self.source_camera = None
        self.pipeline = None
        
    @classmethod
    #constructor
    async def new(cls, config: ComponentConfig, dependencies: Mapping[ResourceName, ResourceBase]):
        camera = cls(config.name)
        await camera.reconfigure(config, dependencies)
        return camera
        
    @classmethod
    async def validate_config(cls, config: ComponentConfig) -> Tuple[Sequence[str], Sequence[str]]:
        req_deps = []
        fields = config.attributes.fields
        if "camera_name" not in fields:
            raise Exception("missing required camera_name attribute")
        elif not fields["camera_name"].HasField("string_value"):
            raise Exception("camera_name must be a string")
        camera_name = fields["camera_name"].string_value
        if not camera_name:
            raise ValueError("camera_name cannot be empty")
        req_deps.append(camera_name)
        return req_deps, []
    
    async def get_image(self) -> ViamImage:
        source_image = await self.source_camera.get_image()
        return self.pipeline.transform(source_image)
        
    async def get_images(self, *, timeout: Optional[float] = None) -> Tuple[List[NamedImage], ResponseMetadata]:
        return NotImplementedError

    async def get_point_cloud(self, *, timeout: Optional[float] = None) -> Tuple[bytes, str]:
        return NotImplementedError

    async def get_properties(self, *, timeout: Optional[float] = None, **kwargs) -> Properties:
        source_properties = await self.source_camera.get_image().get_properties()
        return source_properties
    
    async def reconfigure(
        self, config: ComponentConfig, dependencies: Mapping[ResourceName, ResourceBase]):
        camera_name = config.attributes.fields["camera_name"].string_value
        camera_resource = dependencies[Camera.get_resource_name(camera_name)]
        self.source_camera = cast(Camera, camera_resource)
        self.camera_name = camera_name
        if "pipeline" in config.attributes.fields:
            pipeline_config = config.attributes.fields["pipeline"].list_value
            self.pipeline = GPUTransformPipeline(pipeline_config)
        return super().reconfigure(config, dependencies)


    async def close(self):
        self.source_camera = None
        self.pipeline = None
